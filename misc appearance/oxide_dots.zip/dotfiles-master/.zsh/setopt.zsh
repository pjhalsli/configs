# Prompting.
setopt PROMPT_CR
setopt PROMPT_SP

# History.
setopt INC_APPEND_HISTORY
setopt SHARE_HISTORY

# Directory.
setopt AUTO_PUSHD
setopt PUSHD_IGNORE_DUPS
setopt PUSHD_MINUS
